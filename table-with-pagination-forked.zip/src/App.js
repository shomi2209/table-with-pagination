import logo from "./logo.svg";
import "./App.css";
import Posts from "./components/posts";

function App() {
  return (
    <div>
      <Posts />
    </div>
  );
}

export default App;
