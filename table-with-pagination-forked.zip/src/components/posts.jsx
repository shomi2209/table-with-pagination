import React, { useEffect, useState } from "react";
import axios from "axios";
//import _ from "lodash";

const pageSize = 10;
const Posts = () => {
  const [posts, setposts] = useState([]);
  const [paginatedPosts, setpaginatedPosts] = useState([]);
  const [currentPage, setcurrentPage] = useState(1);
  //const [State, setState] = useState();

  //const take = (arr, qty =1) =>  [...arr].splice(0, qty);

  useEffect(() => {
    axios.get("https://jsonplaceholder.typicode.com/todos").then((res) => {
      console.log(res.data);
      setposts(res.data);
      //setpaginatedPosts(_(res.data).slice(0).take(pageSize).value())
      //setpaginatedPosts(take((res.data).slice(0).value(), pageSize));
      //setpaginatedPosts((res.data).slice(0,9));
      setpaginatedPosts(
        res.data.slice(currentPage * 10 - 10, currentPage * 10)
      );
    });
  }, [currentPage]);

  const pageCount = posts ? Math.ceil(posts.length / pageSize) : 0;
  if (pageCount === 1) return null;
  //const pages = _.range(1, pageCount+1);
  //const pages = _.range(1, pageCount+1);
  //const pages = [...Array(pageCount).keys()].slice(1);
  const pages = [...Array(pageCount).keys()].map((k) => k + 1);
  console.log(pages);
  const pagination = (pageNo) => {
    setcurrentPage(pageNo);
    const startIndex = (pageNo - 1) * pageSize;
    //const paginatedPosts = _(posts).slice(startIndex).take(pageSize).value();
    //const paginatedPosts = take((posts).slice(startIndex).value() ,pageSize);
    const paginatedPosts = posts.slice(startIndex - 10, startIndex);
    setpaginatedPosts(paginatedPosts);
  };

  return (
    <div>
      {!paginatedPosts ? (
        "No data found!"
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>User ID</th>
              <th>Title</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {paginatedPosts.map((post, index) => (
              <tr key={index}>
                <td>{post.id}</td>
                <td>{post.userId}</td>
                <td>{post.title}</td>
                <td>
                  <p
                    className={
                      post.completed ? "btn btn-success" : "btn btn-danger"
                    }
                  >
                    {post.completed ? "Completed" : "Pending"}
                  </p>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <nav className="d-flex justify-content-center">
        <ul className="pagination">
          {
            <button
              className="btn btn-link"
              onClick={() => {
                setcurrentPage(currentPage - 1);
                pagination(currentPage - 1);
              }}
            >
              Previous
            </button>
          }
          {pages.map((page) => (
            <li
              className={
                page === currentPage ? "page-item active" : "page-item"
              }
            >
              <p className="page-link" onClick={() => pagination(page)}>
                {page}
              </p>
            </li>
          ))}
          {
            <button
              className="btn btn-link"
              onClick={() => {
                setcurrentPage(currentPage + 1);
                pagination(currentPage + 1);
              }}
            >
              Next
            </button>
          }
        </ul>
      </nav>
    </div>
  );
};

export default Posts;
